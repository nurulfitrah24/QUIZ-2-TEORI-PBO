/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 package Mobil;

import java.awt.*;
import java.awt.event.*;
public class Mobil extends Frame implements ActionListener{
    int x = 100;
    int y = 100;
public static void main(String[] args) {
    Frame frame = new Mobil();
    frame.setSize(640, 480);
    frame.setVisible(true);
}
public Mobil() {
// end program when window is closed
    WindowListener l = new WindowAdapter()  {
    public void windowClosing(WindowEvent ev) {
    System.exit(0);
    }
    };
this.addWindowListener(l);
// mouse event handler
MouseListener mouseListener = new MouseAdapter() {
public void mouseClicked(MouseEvent ev) {
    x = ev.getX();
    y = ev.getY();
    repaint();
}
};
addMouseListener(mouseListener);
}

public void paint(Graphics g) {
setBackground (Color.GRAY);

g.setColor(Color.white);
g.setColor(Color.blue);
g.fillRect(200,150,120,55);
g.fillRect(200,205,200,65);
g.drawLine(x +210,150 , 200 , 150);
g.drawLine(x +300,270 ,  200 ,270);

g.drawLine(x +100,150, 200,270);
g.drawLine(x +210,150, 310,205);
g.drawLine(x +300,205, 400,270);
g.setColor(Color.black);
g.drawLine(x +100,205,x +300,205);
g.setColor(Color.red);
g.fillOval(215, 235, 80, 70);
g.fillOval(305, 235, 80, 70);
}
public void actionPerformed(ActionEvent ev) {
String command = ev.getActionCommand();
if ("Close".equals(command)) {
System.exit(0);

}
}
}